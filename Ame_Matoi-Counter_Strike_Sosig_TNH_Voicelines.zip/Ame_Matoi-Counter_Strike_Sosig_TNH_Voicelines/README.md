### Counter Strike Source Bot Radio Voice Pack for TNH



Replaces all sosig voice lines in H3VR with the **classic Counter-Strike: Source bot dialogue.** Now your sosigs will sound like they're straight outta a 2004 LAN party!



Hear your enemies yell "NEGATIVE!" when they miss, "AFFIRMATIVE!" when they spot you, and the iconic **"TAKING FIRE, NEED ASSISTANCE!"** as you light them up. It's like fighting a squad of Expert bots, except they actually have aim.



Perfect for anyone who grew up getting destroyed by bots on Dust 2 and wants that nostalgic vibe while blasting through Take and Hold.



This is the first mod I make for H3VR, so I hope you enjoy it, because I didn't enjoy combing through **400+ files** that thankfully had descriptive audio file names and were also already in WAV format. If you have any questions or any voice line requests, let me know through Discord: @ame\_matoi



Thank you for trying my mod!

